import $ from 'jquery'
import 'slick-carousel'

$('.slick-s').slick()
console.log('slick-s init')
