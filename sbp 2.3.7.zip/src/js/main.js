import svg4everybody from 'svg4everybody'
import './components/slick-init'
import './components/components'

svg4everybody()

console.info('main.js')
// alert('rr23r')
